# LeaderElection-InDistributedSystem

This is a project work for our Distributed Systems course.

The aim of the project is to run a leader election in the distributed system. The algorithm that we are implementing here is the Peleg's Leader Election Algorithm.
